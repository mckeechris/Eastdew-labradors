# Eastdew Labradors 2.0 — production candidate

Static, dependency-free website for GitHub Pages or equivalent static hosting.

## Main pages
Home · About Eastdew · Our Dogs · Candy · Comet · Nova · Litters · Puppy Guide · Contact

## Photography
Real Eastdew photographs available in the working library have been used where identity is safely verifiable. The Luna-with-puppy artwork is intentionally retained as requested by Chris.

## Before public launch
- Replace any dog image whose final Candy/Comet/Nova identity is not yet confirmed by Chris.
- Add verified contact details.
- Verify all show results, health clearances and pedigree data before publishing.
- Point the repository to this folder and enable GitHub Pages.
